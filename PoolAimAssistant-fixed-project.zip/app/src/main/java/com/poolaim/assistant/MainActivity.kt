package com.poolaim.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.poolaim.assistant.calibration.TableCalibrationActivity
import com.poolaim.assistant.databinding.ActivityMainBinding
import com.poolaim.assistant.service.OverlayAimService

/**
 * MainActivity handles:
 * 1. Android SYSTEM_ALERT_WINDOW ("Appear on top") permission check and request
 * 2. Samsung One UI specific power management & battery optimization exemptions
 * 3. Starting/Stopping the floating practice assistant service
 * 4. Navigating to the manual table calibration screen
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Permission launcher for Settings.ACTION_MANAGE_OVERLAY_PERMISSION
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        updatePermissionStatus()
        if (Settings.canDrawOverlays(this)) {
            Snackbar.make(binding.root, "Overlay permission granted! You can now start the assistant.", Snackbar.LENGTH_LONG).show()
        } else {
            showPermissionExplanationDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        updatePermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupClickListeners() {
        // Overlay Permission Button
        binding.btnGrantPermission.setOnClickListener {
            requestOverlayPermission()
        }

        // Start Service Button
        binding.btnStartService.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            startOverlayService()
        }

        // Stop Service Button
        binding.btnStopService.setOnClickListener {
            stopOverlayService()
        }

        // Table Calibration Button
        binding.btnCalibrateTable.setOnClickListener {
            val intent = Intent(this, TableCalibrationActivity::class.java)
            startActivity(intent)
        }

        // Battery Optimization Exemption (Crucial for Samsung Galaxy Devices)
        binding.btnBatteryOptimization.setOnClickListener {
            requestIgnoreBatteryOptimization()
        }
    }

    private fun updatePermissionStatus() {
        val hasOverlay = Settings.canDrawOverlays(this)
        binding.txtOverlayStatus.text = if (hasOverlay) "Granted (Ready)" else "Required"
        binding.txtOverlayStatus.setTextColor(
            getColor(if (hasOverlay) R.color.status_granted else R.color.status_warning)
        )
        binding.btnGrantPermission.isEnabled = !hasOverlay
        binding.btnStartService.isEnabled = hasOverlay

        // Check Battery Optimization on Samsung One UI
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isIgnoringBattery = powerManager.isIgnoringBatteryOptimizations(packageName)
        binding.txtBatteryStatus.text = if (isIgnoringBattery) "Unrestricted" else "Optimized (May stop in background)"
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return

        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            overlayPermissionLauncher.launch(intent)
        } catch (e: Exception) {
            // Samsung fallback: some One UI builds restrict direct package URI
            val genericIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            overlayPermissionLauncher.launch(genericIntent)
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Please disable battery optimization in Samsung Settings > Apps", Toast.LENGTH_LONG).show()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayAimService::class.java).apply {
            action = OverlayAimService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Aim Assistant floating bubble activated", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlayService() {
        val intent = Intent(this, OverlayAimService::class.java).apply {
            action = OverlayAimService.ACTION_STOP
        }
        startService(intent)
        Toast.makeText(this, "Aim Assistant stopped", Toast.LENGTH_SHORT).show()
    }

    private fun showPermissionExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Floating Overlay Required")
            .setMessage("Pool Aim Assistant operates as a legitimate practice aid by drawing geometric aiming lines over your screen while practicing 8 Ball Pool.\n\nIt does not touch game memory, network packets, or game code. To draw these lines, Android requires 'Appear on top' permission.")
            .setPositiveButton("Open Settings") { _, _ -> requestOverlayPermission() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}