package com.poolaim.assistant.calibration

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.poolaim.assistant.model.TableCalibration
import kotlin.math.abs

class TableCalibrationCanvas(context: Context) : View(context) {
    private var calibration = TableCalibration.createDefaultPreset(1080f, 1920f)
    private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(16, 110, 75); style = Paint.Style.FILL }
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(110, 65, 35); style = Paint.Style.STROKE; strokeWidth = 18f }
    private val anchorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(234, 179, 8); style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f; setShadowLayer(3f, 1f, 1f, Color.BLACK) }
    private var dragging = -1

    fun setCalibration(value: TableCalibration) { calibration = value; invalidate() }
    fun getCalibration(): TableCalibration = calibration

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val sx = width / 1080f
        val sy = height / 1920f
        val left = calibration.left * sx
        val top = calibration.top * sy
        val right = calibration.right * sx
        val bottom = calibration.bottom * sy
        canvas.drawColor(Color.rgb(2, 44, 34))
        canvas.drawRoundRect(RectF(left, top, right, bottom), 28f, 28f, tablePaint)
        canvas.drawRoundRect(RectF(left, top, right, bottom), 28f, 28f, railPaint)
        val points = arrayOf(floatArrayOf(left, top), floatArrayOf(right, top), floatArrayOf(left, bottom), floatArrayOf(right, bottom))
        points.forEachIndexed { i, p -> canvas.drawCircle(p[0], p[1], 22f, anchorPaint); canvas.drawText("${i + 1}", p[0] + 25f, p[1] - 25f, textPaint) }
        canvas.drawText("Drag the 4 yellow corners to fit the table", 24f, height - 36f, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val sx = width / 1080f
        val sy = height / 1920f
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val corners = arrayOf(floatArrayOf(calibration.left * sx, calibration.top * sy), floatArrayOf(calibration.right * sx, calibration.top * sy), floatArrayOf(calibration.left * sx, calibration.bottom * sy), floatArrayOf(calibration.right * sx, calibration.bottom * sy))
                dragging = corners.indices.minByOrNull { i -> (corners[i][0] - event.x) * (corners[i][0] - event.x) + (corners[i][1] - event.y) * (corners[i][1] - event.y) } ?: -1
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging >= 0) {
                val x = (event.x / sx).coerceIn(0f, 1080f)
                val y = (event.y / sy).coerceIn(0f, 1920f)
                when (dragging) {
                    0 -> { calibration.left = x; calibration.top = y }
                    1 -> { calibration.right = x; calibration.top = y }
                    2 -> { calibration.left = x; calibration.bottom = y }
                    3 -> { calibration.right = x; calibration.bottom = y }
                }
                if (calibration.right - calibration.left < 100f) calibration.right = calibration.left + 100f
                if (calibration.bottom - calibration.top < 100f) calibration.bottom = calibration.top + 100f
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = -1; performClick(); return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
