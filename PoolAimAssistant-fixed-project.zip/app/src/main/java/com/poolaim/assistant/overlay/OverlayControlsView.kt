package com.poolaim.assistant.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import com.poolaim.assistant.R
import com.poolaim.assistant.calibration.TableCalibrationActivity

@SuppressLint("ViewConstructor")
class OverlayControlsView(
    context: Context,
    private val onLockToggled: (Boolean) -> Unit,
    private val onCushionBounceToggled: (Boolean) -> Unit,
    private val onCloseRequested: () -> Unit
) : FrameLayout(context) {

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private var isExpanded = false
    private var isLocked = false
    private var isBounceActive = true

    private val bubbleBtn: ImageButton
    private val menuPanel: LinearLayout
    private val lockBtn: ImageButton
    private val bounceBtn: ImageButton
    private val calibrateBtn: ImageButton
    private val closeBtn: ImageButton

    init {
        LayoutInflater.from(context).inflate(R.layout.view_overlay_controls, this, true)

        bubbleBtn = findViewById(R.id.btnFloatingBubble)
        menuPanel = findViewById(R.id.panelExpandedMenu)
        lockBtn = findViewById(R.id.btnToggleLock)
        bounceBtn = findViewById(R.id.btnToggleBounce)
        calibrateBtn = findViewById(R.id.btnOpenCalibration)
        closeBtn = findViewById(R.id.btnCloseOverlay)

        setupInteractions()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupInteractions() {
        // Draggable bubble logic
        bubbleBtn.setOnTouchListener { _, event ->
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val params = layoutParams as WindowManager.LayoutParams

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    wm.updateViewLayout(this, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    // Check if click vs drag
                    val diffX = Math.abs(event.rawX - initialTouchX)
                    val diffY = Math.abs(event.rawY - initialTouchY)
                    if (diffX < 15 && diffY < 15) {
                        toggleExpanded()
                    }
                    true
                }
                else -> false
            }
        }

        lockBtn.setOnClickListener {
            isLocked = !isLocked
            lockBtn.setImageResource(if (isLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
            onLockToggled(isLocked)
        }

        bounceBtn.setOnClickListener {
            isBounceActive = !isBounceActive
            bounceBtn.alpha = if (isBounceActive) 1.0f else 0.4f
            onCushionBounceToggled(isBounceActive)
        }

        calibrateBtn.setOnClickListener {
            val intent = Intent(context, TableCalibrationActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }

        closeBtn.setOnClickListener {
            onCloseRequested()
        }
    }

    private fun toggleExpanded() {
        isExpanded = !isExpanded
        menuPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
    }
}