package com.poolaim.assistant.calibration

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.poolaim.assistant.databinding.ActivityTableCalibrationBinding
import com.poolaim.assistant.model.TableCalibration
import com.poolaim.assistant.repository.TableCalibrationRepository

/**
 * Activity that lets the user drag the 4 corner anchors of the pool table
 * and adjust cushion boundaries to match 8 Ball Pool's exact viewport.
 */
class TableCalibrationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTableCalibrationBinding
    private lateinit var currentCalibration: TableCalibration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()

        binding = ActivityTableCalibrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentCalibration = TableCalibrationRepository.loadCalibration(this)
        binding.calibrationCanvas.setCalibration(currentCalibration)

        setupListeners()
    }

    private fun setupListeners() {
        binding.btnSaveCalibration.setOnClickListener {
            val updated = binding.calibrationCanvas.getCalibration()
            TableCalibrationRepository.saveCalibration(this, updated)
            Toast.makeText(this, "Table calibration saved successfully!", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnResetPreset.setOnClickListener {
            val defaultCalib = TableCalibration.createDefaultPreset(
                screenWidth = resources.displayMetrics.widthPixels.toFloat(),
                screenHeight = resources.displayMetrics.heightPixels.toFloat()
            )
            binding.calibrationCanvas.setCalibration(defaultCalib)
            Toast.makeText(this, "Reset to standard 8 Ball Pool aspect ratio", Toast.LENGTH_SHORT).show()
        }

        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }
}