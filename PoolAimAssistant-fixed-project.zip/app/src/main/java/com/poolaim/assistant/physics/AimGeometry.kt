package com.poolaim.assistant.physics

import android.graphics.PointF
import com.poolaim.assistant.model.TableCalibration
import kotlin.math.*

data class AimResult(
    val ghostBall: PointF?,
    val targetTrajectoryEnd: PointF,
    val cushionBounceEnd: PointF?,
    val cutAngleDeg: Double,
    val hasCollision: Boolean
)

object AimGeometry {

    fun calculate(
        cueX: Float,
        cueY: Float,
        targetX: Float,
        targetY: Float,
        aimAngleRad: Double,
        ballRadius: Float,
        table: TableCalibration,
        calculateBounce: Boolean
    ): AimResult {
        val dirX = cos(aimAngleRad).toFloat()
        val dirY = sin(aimAngleRad).toFloat()

        // 1. Ray-Circle collision check between Cue Ball ray and Object Ball (at 2 * R distance)
        val collisionDist = rayCircleIntersection(
            rayOriginX = cueX,
            rayOriginY = cueY,
            dirX = dirX,
            dirY = dirY,
            centerX = targetX,
            centerY = targetY,
            radius = ballRadius * 2f
        )

        if (collisionDist == null || collisionDist <= 0) {
            // No direct ball collision; cue ray reaches table cushion
            val cushionHit = intersectCushion(cueX, cueY, dirX, dirY, table, ballRadius)
            val endPoint = cushionHit?.point ?: PointF(cueX + dirX * 800f, cueY + dirY * 800f)

            return AimResult(
                ghostBall = null,
                targetTrajectoryEnd = endPoint,
                cushionBounceEnd = null,
                cutAngleDeg = 0.0,
                hasCollision = false
            )
        }

        // 2. Ghost ball position (center of cue ball at moment of contact)
        val ghostX = cueX + dirX * collisionDist
        val ghostY = cueY + dirY * collisionDist
        val ghostBall = PointF(ghostX, ghostY)

        // 3. Impact normal: vector from ghost ball to target ball
        var normalX = targetX - ghostX
        var normalY = targetY - ghostY
        val normalLen = hypot(normalX.toDouble(), normalY.toDouble()).toFloat()
        if (normalLen > 1e-4) {
            normalX /= normalLen
            normalY /= normalLen
        }

        // 4. Cut Angle (angle between cue travel dir and impact normal)
        val dot = max(-1.0f, min(1.0f, dirX * normalX + dirY * normalY))
        val cutAngleDeg = acos(dot.toDouble()) * (180.0 / Math.PI)

        // 5. Target ball travel ray along impact normal to cushion
        val targetCushionHit = intersectCushion(targetX, targetY, normalX, normalY, table, ballRadius)
        val targetEnd = targetCushionHit?.point ?: PointF(targetX + normalX * 600f, targetY + normalY * 600f)

        // 6. Specular reflection bounce off cushion
        var bounceEnd: PointF? = null
        if (calculateBounce && targetCushionHit != null) {
            val cNorm = targetCushionHit.normal
            val dDotN = normalX * cNorm.x + normalY * cNorm.y
            val reflectX = normalX - 2f * dDotN * cNorm.x
            val reflectY = normalY - 2f * dDotN * cNorm.y

            val secondHit = intersectCushion(
                targetCushionHit.point.x, targetCushionHit.point.y,
                reflectX, reflectY, table, ballRadius
            )
            bounceEnd = secondHit?.point ?: PointF(
                targetCushionHit.point.x + reflectX * 300f,
                targetCushionHit.point.y + reflectY * 300f
            )
        }

        return AimResult(
            ghostBall = ghostBall,
            targetTrajectoryEnd = targetEnd,
            cushionBounceEnd = bounceEnd,
            cutAngleDeg = cutAngleDeg,
            hasCollision = true
        )
    }

    private fun rayCircleIntersection(
        rayOriginX: Float, rayOriginY: Float,
        dirX: Float, dirY: Float,
        centerX: Float, centerY: Float,
        radius: Float
    ): Float? {
        val ocX = rayOriginX - centerX
        val ocY = rayOriginY - centerY
        val a = dirX * dirX + dirY * dirY
        val b = 2f * (ocX * dirX + ocY * dirY)
        val c = (ocX * ocX + ocY * ocY) - radius * radius

        val discriminant = b * b - 4f * a * c
        if (discriminant < 0) return null

        val sqrtDisc = sqrt(discriminant.toDouble()).toFloat()
        val t1 = (-b - sqrtDisc) / (2f * a)
        val t2 = (-b + sqrtDisc) / (2f * a)

        return when {
            t1 > 0 -> t1
            t2 > 0 -> t2
            else -> null
        }
    }

    data class CushionHit(val point: PointF, val normal: PointF)

    private fun intersectCushion(
        origX: Float, origY: Float,
        dirX: Float, dirY: Float,
        table: TableCalibration,
        margin: Float
    ): CushionHit? {
        val left = table.left + margin
        val right = table.right - margin
        val top = table.top + margin
        val bottom = table.bottom - margin

        var minT = Float.MAX_VALUE
        var hit: CushionHit? = null

        if (dirX < -1e-4) {
            val t = (left - origX) / dirX
            if (t > 0.01f && t < minT) {
                val y = origY + dirY * t
                if (y in top..bottom) {
                    minT = t
                    hit = CushionHit(PointF(left, y), PointF(1f, 0f))
                }
            }
        }
        if (dirX > 1e-4) {
            val t = (right - origX) / dirX
            if (t > 0.01f && t < minT) {
                val y = origY + dirY * t
                if (y in top..bottom) {
                    minT = t
                    hit = CushionHit(PointF(right, y), PointF(-1f, 0f))
                }
            }
        }
        if (dirY < -1e-4) {
            val t = (top - origY) / dirY
            if (t > 0.01f && t < minT) {
                val x = origX + dirX * t
                if (x in left..right) {
                    minT = t
                    hit = CushionHit(PointF(x, top), PointF(0f, 1f))
                }
            }
        }
        if (dirY > 1e-4) {
            val t = (bottom - origY) / dirY
            if (t > 0.01f && t < minT) {
                val x = origX + dirX * t
                if (x in left..right) {
                    minT = t
                    hit = CushionHit(PointF(x, bottom), PointF(0f, -1f))
                }
            }
        }
        return hit
    }
}